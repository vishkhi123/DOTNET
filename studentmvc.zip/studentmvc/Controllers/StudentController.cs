using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using studentmvc.Models;
using BOL;
using DAL;
namespace studentmvc.Controllers;

public class StudentController : Controller
{
    private readonly ILogger<StudentController> _logger;

    public StudentController(ILogger<StudentController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        List<Student> stud=StudentAccessData.GetAllStudent();
        this.ViewBag.STUD=stud;
        return View();
    }
    [HttpPost]
     public IActionResult StudDetail(int id)
    {
         Student s=StudentAccessData.GetById(id);
         this.ViewBag.S=s;
        
        return View();
    }
  
    public IActionResult Delete(int id)
    {
        StudentAccessData.DeleteById(id);
        return RedirectToAction("Index");
    }

    [HttpGet]
     public IActionResult Add()
    {   
        Student st=new Student();
        return View(st);
    }
    [HttpPost]
     public IActionResult Add(Student stud)
    {
        StudentAccessData.AddStudent(stud);
        return RedirectToAction("Index");
    }

     [HttpGet]
     public IActionResult Update()
    {   
        return View();
    }

     [HttpPost]
     public IActionResult Update(Student stud)
    {   
        StudentAccessData.UpdateStudent(stud);
        return RedirectToAction("Index");
    }


   

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
