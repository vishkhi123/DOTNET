namespace BOL;

public class Student
{
    public int id{get;set;}

    public string? name{get;set;}

    public string? place{get;set;}
}