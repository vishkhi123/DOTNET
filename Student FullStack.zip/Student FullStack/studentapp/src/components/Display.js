import axios from "axios";
import { useEffect, useState } from "react";


const Display = (props) => {
    const [apiData, setApiData] = useState([]);

    useEffect(
        () => {
            axios.get('http://localhost:5037/api/student')
                .then(resp => { setApiData(resp.data) });
        }
    )
    var tablerows = apiData.map(obj => {
        return (
            <tr>
                <td>{obj.id}</td>
                <td>{obj.name}</td>
                <td>{obj.place}</td>
            </tr>
        )
    })


    return (
        <>
            <br /><br />
            <table id="studentsTable" border="2px">
                <tr>
                    <td>Id</td>
                    <td>Name</td>
                    <td>Place</td>     
                </tr>
                {tablerows}
            </table>
        </>
    )


}
export default Display;