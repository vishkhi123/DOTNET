import { useState } from "react";
import axios from 'axios';
const Insert=(props)=>{
    const [apiData, setApiData] = useState({id:"",name:"",place:""});
    
    const savedata = (event) => {
        event.preventDefault();
        axios.post('http://localhost:5037/api/student', apiData);
    }

    const handleChange=(event)=>{
        const {name,value} =event.target
        setApiData({...apiData,[name]:value})

    }

return(

    <div>

        <h1>In Insert</h1>
        <br></br>
        <h4>Add new user</h4>
            <form method="POST" onSubmit={savedata}>
                <input type="number" name="id" onChange={handleChange} placeholder="Enter ID"/>
                <input type="text" name="name" onChange={handleChange} placeholder="Enter Name"/>
                <input type="text" name="place" onChange={handleChange} placeholder="Enter Place"/>
                <input type="Submit"/>
            </form>

    </div>
)



}
export default Insert;