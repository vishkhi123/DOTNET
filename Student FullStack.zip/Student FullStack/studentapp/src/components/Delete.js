import { useState } from "react";
import axios from 'axios';
const Delete=(props)=>{
    const [apiData, setApiData] = useState({id:""});
    
    const deleteStd = (event) => {
        event.preventDefault();
        axios.delete(`http://localhost:5037/api/student/${apiData.id}`);
    }

    const handleChange=(event)=>{
        const {name,value} =event.target
        setApiData({...apiData,[name]:value})
    }


return(

    <div>
        <br/><br/>
            <h4>Enter student's Id to be deleted.</h4>
            <form method="GET" onSubmit={deleteStd}>
                <input type="text" name="id" onChange={handleChange} placeholder="Enter Id"/>
                <input type="Submit" value="Delete"/>
            </form>

    </div>
)


}
export default Delete;