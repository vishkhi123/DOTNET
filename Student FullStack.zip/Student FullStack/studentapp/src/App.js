import logo from './logo.svg';
import './App.css';
import Display from './components/Display';
import Insert from './components/Insert';
import Delete from './components/Delete';

function App() {
  return (
    <div className="App">
     <h1>In ReactApp</h1>
     <Display></Display>
     <Insert></Insert>
     <Delete></Delete>
    </div>
  );
}

export default App;
